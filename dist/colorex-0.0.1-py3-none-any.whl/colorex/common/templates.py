'''

Copyright 2019 Louis Ronald

Permission is hereby granted, free of charge, to any person 
obtaining a copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, 
publish, distribute, sublicense, and/or sell copies of the Software, 
and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
DEALINGS IN THE SOFTWARE.



'''

import xml.etree.ElementTree as ET


class Templates:

    def __init__(self):
        # general templates repo.
        self.__templates = dict()


        # declare default template.
        default = dict()
        default['name'] = 'default'
        default['template'] = '''



<html>
    <head>
        <title>
            ColorEx
        </title>
		
        <style>
			body {
				font-family: Roboto;
				font-size: 15pt;
				background-color: white;
			}
			
			.tile {
				height: 100px;
				width: 100px;
				padding-top: 0px;
				vertical-align: middle;
				text-align: center;
				font-size: 20px;
				font-family: Roboto;
				margin: 3px;
				border-radius: 8px;
				color: white;
				
			}

			.tile-grid {
				border: 1px solid black;
				padding: 20px;
				background-color: #808080;
			}
			
			
			.column-labels {
				text-align: center;
				font-family: Roboto;
				font-weight: bolder;
				display: block;
				transform: rotate(270deg);
				color: white;
			}
			
			.title {
				vertical-align: middle;
				text-align: center;
				font-size: 26pt;
				font-weight: bolder;
				font-family: Roboto;
				color: white;	
			}

			.subtitle {
				vertical-align: middle;
				text-align: center;
				font-size: 17pt;
				font-weight: bolder;
				color: white;
				font-family: Roboto;	
			}			

			
        </style>
        
    </head>

    <body>

	
    	<div id='status'></div>

		<table class="tile-grid">
			#set $nCols=len($column_labels)
			<tr>
				<td colspan="$nCols" class="title">$title</td>
			</tr>
			<tr>
				<td colspan="$nCols" class="subtitle">$subtitle</td>
			</tr>
			
			
			
			<tr>
				#for $label in $column_labels
				<td style="height: 200px;">
					<p class="column-labels">$label</p>
				</td>
				#end for
			</tr>
			#for $row in $color_grid
			<tr>
				#for $item in $row
				<td style="color: white;">
					#try
						#silent $item.value
						<div class="tile" style="background-color: rgba($item.rgb[0], $item.rgb[1], $item.rgb[2], $item.alpha); border: 2px solid rgba($item.rgb[0], $item.rgb[1], $item.rgb[2], $item.alpha);" 
							onmouseover="mouse_over_tile(this, $item.value)" onmouseout="mouse_out_tile(this)"
						>
							<table height="100%" width="100%"
							style="text-align: center;"
							>
								<tr>
									<td>
										<!-- $item.value -->
									</td>
								</tr>
							</table>
						</div>
					#except
						$item
					#end try
				</td>
				#end for
			</tr>
			#end for
		</table>
		
    </body>
</html>





        '''

    
        # add all declared templates to the repo.
        self.__templates['default'] = default



    @property
    def templates(self):
        ''' returns list of in-built templates '''
        return self.__templates

















class Template:

    def __init__(self, filename=None, name='default'):

        if(filename == None and name == 'default'):
            pass
            



    @property
    def template(self):
        ''' returns the actual template data '''
        return self.__template

